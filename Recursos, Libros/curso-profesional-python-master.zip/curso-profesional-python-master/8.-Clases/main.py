#           0       1   2       3       4          5
tupla = ('String', 10, 15.4, True, [1, 2, 3], (4, 5, 6))

print(tupla)