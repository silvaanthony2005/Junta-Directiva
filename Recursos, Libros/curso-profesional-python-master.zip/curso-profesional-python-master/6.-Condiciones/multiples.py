calificacion = 4

if calificacion == 10:
   print('Felicidades, aprobaste la materia con una calificación perfecta.')
elif calificacion == 9 or calificacion == 8:
    print('Felicidades, aprobate la materia.')
elif calificacion == 7 or calificacion == 6:
    print('Aprobaste la materia.')
else:
    print('Reprobaste la materia.')