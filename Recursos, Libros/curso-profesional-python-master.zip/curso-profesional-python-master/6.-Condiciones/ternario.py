calificacion = 10

color = 'Verde' if calificacion >= 7 else 'Rojo'

print(calificacion, color)