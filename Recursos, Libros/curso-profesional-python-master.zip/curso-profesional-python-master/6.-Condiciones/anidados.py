calificacion = 8

if calificacion == 10:
    print('Felicidades, aprobaste con una calificación perfecta.')
else:
    print('Reprobate la materia.')