resultado = 15

if resultado > 10 and resultado < 20:
    print('La variable cumple con la condición.')
else:
    print('La condición no se cumplio :( ')