resultado = None # Falso

resultado = [1, 2, 3]

print(resultado)
print(type(resultado))

# True (1) / False (0)

"""
False
None
0
0.0
'' / ""
[]
()
{}
"""