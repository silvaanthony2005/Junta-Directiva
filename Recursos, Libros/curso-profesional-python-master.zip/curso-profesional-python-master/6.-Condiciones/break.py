titulo_curso = 'Curso profesional de Python'

for caracter in titulo_curso:

    if caracter == 'P':
        continue # break

    print(caracter)