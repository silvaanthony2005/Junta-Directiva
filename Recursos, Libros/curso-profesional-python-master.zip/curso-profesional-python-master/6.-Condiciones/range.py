# start = 0, end, skips
# for valor in range(5, 21, 3):
#    print(valor)

numeros = [10, 20, 30, 40, 50]

for indice, numero in enumerate(numeros):
    print(indice, numero)
