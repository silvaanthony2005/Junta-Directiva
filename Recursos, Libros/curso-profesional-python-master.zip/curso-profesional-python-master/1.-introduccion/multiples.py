nombre, apellido, titulo = 'Eduardo', 'García', 'Mr.'

print(nombre)
print(apellido)
print(titulo)