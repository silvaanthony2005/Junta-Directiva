# Esta línea se encuentra comentada.
print('Hola mundo')

"""
Este es un comentario
que posee saltos
de línea.
"""