valor = "Eduardo"
print(type(valor))

valor = 2
print(type(valor))

valor = 3.1
print(type(valor))

valor = True
print(type(valor))