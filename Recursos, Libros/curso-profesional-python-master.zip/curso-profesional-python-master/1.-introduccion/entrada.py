nombre_completo = input('Ingresa tu nombre completo: ') # str

edad = int(input('Ingresa tu edad: '))

altura = float(input('Ingresa tu altura: '))

autorizacion = input('¿Autorizas el programa? (si/no)') == 'si'

print(nombre_completo)
print(edad)
print(altura)
print(autorizacion)