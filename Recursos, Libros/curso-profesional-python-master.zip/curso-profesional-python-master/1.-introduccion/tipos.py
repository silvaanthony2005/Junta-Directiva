# String
titulo_curso = 'Curso profesional de Python'
print(titulo_curso)

nombre_completo = "Eduardo Ismael"
print(nombre_completo)

mensaje = '''Te encuentras
en el curso: Profesional de Python.
En CódigoFacilito'''

print(mensaje)

# Int
# Al divir con / Obtenemos un tipo de dato flotante
# Al divir con // Obtenemos un tipo de dato entero
numero_uno = 10 // 3 
print(numero_uno)

# Float
numero_dos = -3.14
print(numero_dos)

# Bool
# True - False
valor = False 
print(valor)