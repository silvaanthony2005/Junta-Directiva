numero_uno = 20
numero_dos = 50

"""
    >
    <
    >=
    <=
    ==
    !=
"""

resulto = numero_uno == numero_dos
print(resulto)