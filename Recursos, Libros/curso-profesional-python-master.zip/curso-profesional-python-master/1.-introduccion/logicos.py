# and, or y not

resultado_final = not True
print(resultado_final)