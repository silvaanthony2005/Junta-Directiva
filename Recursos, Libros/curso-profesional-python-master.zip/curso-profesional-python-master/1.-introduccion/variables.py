titulo_curso = 'Curso profesional de Python'

nombre_completo = 'Eduardo Ismael García Pérez'

print(titulo_curso)