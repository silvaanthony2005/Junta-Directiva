TITULO_CURSO = 'Curso profesional de Python'

print(TITULO_CURSO)