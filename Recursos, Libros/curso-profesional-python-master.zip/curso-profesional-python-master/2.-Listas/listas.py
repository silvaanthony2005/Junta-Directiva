lista = [8, 5, 90, 1, 5, 44, 132, 600, 3, 4, 5]

print(5 in lista)

index = lista.
(5)
print(index)