columna_a = [10, 20, 30, 40]
columna_b = [30, 40, 50, 60]

matriz = [columna_a, columna_b] # 2 x 4

print(matriz[1][3])