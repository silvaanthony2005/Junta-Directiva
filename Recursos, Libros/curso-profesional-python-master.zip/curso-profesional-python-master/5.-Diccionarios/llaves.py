diccionario = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# keys
# values
# items

llaves = tuple(diccionario.keys())
print(llaves)

valores = tuple(diccionario.values())
print(valores)

elementos = tuple(diccionario.items())
print(elementos)