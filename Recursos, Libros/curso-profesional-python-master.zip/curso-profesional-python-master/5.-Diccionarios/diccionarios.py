elementos = {'a': 1, 'b': 2, 'c':3, 'a': 4}

"""
elementos['nombre'] ='Cody' # Crea la llave con su valor
elementos[(1, 2, 3)] ='La llave es una tupla'

# Actualiza el valor de la llave
elementos['nombre'] = 'CódigoFacilito'
"""

print(elementos)
print(len(elementos))