cursos = ['Python', 'Django', 'Flask']

cursos_tupla = tuple(cursos)

print(cursos_tupla)
print(type(cursos_tupla))

niveles = ('Básico', 'Intermedio', 'Avanzado')

niveles_lista = list(niveles)

print(niveles_lista)
print(type(niveles_lista))