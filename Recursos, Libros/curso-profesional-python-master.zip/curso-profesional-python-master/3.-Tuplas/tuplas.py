cursos = ('Python', 'Flask', 'Django', 'Rails', 'MongoDB')
#           0           1       2          3        4

primer_curso = cursos[0]
print(primer_curso)

ultimo_curso = cursos[-1]
print(ultimo_curso)

sub_tupla = cursos[:]
print(sub_tupla)