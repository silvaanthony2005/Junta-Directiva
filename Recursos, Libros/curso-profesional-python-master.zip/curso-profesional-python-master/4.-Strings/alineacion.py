mensaje = 'Hola mundo!'

# ljust -> Justificar a la Izquierda
# rjust -> Justificar a la Derecha
# center -> Centrar

mensaje = mensaje.center(20)

print(mensaje)
