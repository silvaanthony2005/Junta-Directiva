"""
lenguajes = 'Python Ruby Java Rust C++ C'

listado_lenguajes = lenguajes.split('') # espacios 

print(listado_lenguajes)
"""

lenguajes = ['Python', 'Ruby', 'Java', 'Rust']

string_lenguajes = '-'.join(lenguajes)

print(string_lenguajes)
print(type(string_lenguajes))