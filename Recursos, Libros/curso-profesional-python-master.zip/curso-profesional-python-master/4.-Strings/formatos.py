mensaje = '   Curso profesional de Python, donde aprenderemos Python.   '

# mensaje = mensaje.upper()
# mensaje = mensaje.lower()

# mensaje = mensaje.replace(' ', '-')

mensaje = mensaje.strip()

print(mensaje)
# print(mensaje.islower()) # isupper() o islower()