titulo_curso = 'Curso profesional de Python, donde aprenderemos Python'

"""
contador = titulo_curso.count('a')

print(contador)
"""

# startswith
# endswith

print(titulo_curso.endswith('Python'))