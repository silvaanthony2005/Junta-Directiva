nombre = 'Eduardo Ismael'
apellido = 'García'

print(nombre, apellido, 'Pérez', sep=' ')